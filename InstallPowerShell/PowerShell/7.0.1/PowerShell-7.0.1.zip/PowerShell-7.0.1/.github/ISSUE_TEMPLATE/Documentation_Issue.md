---
name: Documentation Issue 📚
about: File issues regarding documentation within the [PowerShell-Docs](https://github.com/MicrosoftDocs/PowerShell-Docs) repository
title: "Documentation Issue"
labels: Issue-Question,Area-Documentation
assignees: ''

---

# Documentation Issue

Please open documentation issues that are not specifically for documentation within the
PowerShell/PowerShell repository in the [PowerShell Docs](https://github.com/MicrosoftDocs/PowerShell-Docs/issues) repository.
