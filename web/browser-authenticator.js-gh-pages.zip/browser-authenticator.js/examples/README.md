See index.html / demo/demo.js and demo/phone.html / demo/phone.js
